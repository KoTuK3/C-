﻿using System.Windows;

namespace Wpf.Controls.ComboBox.Xaml
{
    internal sealed partial class App : Application
    {
    }
}