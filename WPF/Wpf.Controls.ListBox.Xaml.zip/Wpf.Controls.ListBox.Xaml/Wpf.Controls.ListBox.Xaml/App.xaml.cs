﻿using System.Windows;

namespace Wpf.Controls.ListBox.Xaml
{
    internal sealed partial class App : Application
    {
    }
}